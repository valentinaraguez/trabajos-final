package ar.com.practico5.services;

import ar.com.practico5.entities.Ventas;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface IVentasServices {

    List<Ventas> getAll();
    Page<Ventas> findAll(Pageable pageable);
    Ventas get(Integer id);
    void save(Ventas entity);
    String delete(Ventas entity);
}
