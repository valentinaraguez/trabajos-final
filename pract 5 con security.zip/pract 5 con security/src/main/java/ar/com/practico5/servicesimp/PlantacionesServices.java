package ar.com.practico5.servicesimp;

import ar.com.practico5.dao.IPlantacionesDao;
import ar.com.practico5.entities.Plantaciones;
import ar.com.practico5.services.IPlantacionesServices;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PlantacionesServices implements IPlantacionesServices {

    @Autowired
    private IPlantacionesDao entityDao;

    public List<Plantaciones> getAll() { return entityDao.findAll(Sort.by(Sort.Direction.ASC, "periodo"));}

    public Page<Plantaciones> findAll(Pageable pageable) {
        return entityDao.findAll(PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by(Sort.Direction.ASC, "periodo")));
    }

    public Plantaciones get(Integer id) {return  entityDao.findById(id).orElse(null);}

    @Transactional
    public void save(Plantaciones entity) {entityDao.save(entity);}

    @Transactional
    public String delete(Plantaciones entity) {
        try {
            entityDao.delete(entity);
            return null;
        } catch (Exception e) {
            return e.getMessage().toString();
        }
    }
}
