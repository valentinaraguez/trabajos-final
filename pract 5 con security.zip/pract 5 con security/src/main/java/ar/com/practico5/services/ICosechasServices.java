package ar.com.practico5.services;


import ar.com.practico5.entities.Cosechas;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ICosechasServices {
    List<Cosechas> getAll();
    Page<Cosechas> findAll(Pageable pageable);
    Cosechas get(Integer id);
    void save(Cosechas entity);
    String delete(Cosechas entity);

}
