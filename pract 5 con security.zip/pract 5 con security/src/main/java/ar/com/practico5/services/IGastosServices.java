package ar.com.practico5.services;

import ar.com.practico5.entities.Gastos;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface IGastosServices {

    List<Gastos> getAll();
    Page<Gastos> findAll(Pageable pageable);
    Gastos get(Integer id);
    void save(Gastos entity);
    String delete(Gastos entity);
}
