package ar.com.practico5.services;

import ar.com.practico5.entities.Plantaciones;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface IPlantacionesServices {

    List<Plantaciones> getAll();
    Page<Plantaciones> findAll(Pageable pageable);
    Plantaciones get(Integer id);
    void save(Plantaciones entity);
    String delete(Plantaciones entity);
}
