package ar.com.practico5.entities;

import jakarta.persistence.*;

import java.io.Serializable;

@Entity
@Table(name = "lotes")
public class Lotes implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String descrip;
    private Double sup;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }


    public String getDescrip() {
        return descrip;
    }

    public void setDescrip(String descrip) {
        this.descrip = descrip;
    }


    public void setSup(Double sup) {
        this.sup = sup;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Double getSup() {
        return sup;
    }
}
