package ar.com.practico5.services;

import ar.com.practico5.entities.Compradores;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ICompradoresServices {
    List<Compradores> getAll();
    List<Compradores> findByDescrip(String nombre);
    Page<Compradores> findAll(Pageable pageable);
    Compradores get(Integer id);
    void save(Compradores entity);
    String delete(Compradores entity);
}
