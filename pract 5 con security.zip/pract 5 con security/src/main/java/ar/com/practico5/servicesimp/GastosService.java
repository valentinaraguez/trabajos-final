package ar.com.practico5.servicesimp;

import ar.com.practico5.dao.IGastosDao;
import ar.com.practico5.entities.Compradores;
import ar.com.practico5.entities.Gastos;
import ar.com.practico5.services.IGastosServices;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GastosService implements IGastosServices {

    @Autowired
    private IGastosDao entityDao;

    public List<Gastos> getAll(){ return entityDao.findAll(Sort.by(Sort.Direction.ASC, "descrip"));}

    public Page<Gastos> findAll(Pageable pageable) {
        return entityDao.findAll(PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by(Sort.Direction.ASC, "fecha")));
    }

    public Gastos get(Integer id){ return entityDao.findById(id).orElse(null);}

    @Transactional
    public void save(Gastos entity) { entityDao.save(entity);}

    @Transactional
    public String delete(Gastos entity){
        try {
            entityDao.delete(entity);
            return null;
        } catch (Exception e) {
            return e.getMessage().toString();
        }
    }
}
