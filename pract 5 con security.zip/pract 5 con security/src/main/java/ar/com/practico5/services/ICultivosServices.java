package ar.com.practico5.services;

import ar.com.practico5.entities.Cultivos;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ICultivosServices {
    List<Cultivos> getAll();
    Page<Cultivos> findAll(Pageable pageable);
    List<Cultivos> findByDescrip(String descrip);
    Cultivos get(Integer id);
    void save(Cultivos entity);
    String delete(Cultivos entity);
}
