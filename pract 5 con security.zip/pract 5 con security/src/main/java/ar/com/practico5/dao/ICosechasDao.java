package ar.com.practico5.dao;

import ar.com.practico5.entities.Cosechas;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ICosechasDao extends JpaRepository<Cosechas, Integer> {
    Page<Cosechas> findAll(Pageable pageable);
}
