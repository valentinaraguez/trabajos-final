package ar.com.practico5.servicesimp;


import ar.com.practico5.dao.IVentasDao;
import ar.com.practico5.entities.Ventas;
import ar.com.practico5.services.IVentasServices;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VentasServices implements IVentasServices {

    @Autowired
    private IVentasDao entityDao;

    public List<Ventas> getAll(){ return entityDao.findAll(Sort.by(Sort.Direction.ASC, "descrip"));}

    public Page<Ventas> findAll(Pageable pageable) {
        return entityDao.findAll(PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by(Sort.Direction.ASC, "fecha")));
    }

    public Ventas get(Integer id){ return entityDao.findById(id).orElse(null);}

    @Transactional
    public void save(Ventas entity) { entityDao.save(entity);}

    @Transactional
    public String delete(Ventas entity){
        try {
            entityDao.delete(entity);
            return null;
        } catch (Exception e) {
            return e.getMessage().toString();
        }
    }
}
