package ar.com.practico5.controller;


import ar.com.practico5.entities.Gastos;
import ar.com.practico5.entities.Plantaciones;
import ar.com.practico5.services.IGastosServices;
import ar.com.practico5.services.IPlantacionesServices;
import ar.com.practico5.utiles.PageWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@Controller
public class GastosController {

    @Autowired
    IGastosServices entityService;
    @Autowired
    IPlantacionesServices plantacionesServices;
   
   
    @RequestMapping(value = "/gastos", method = RequestMethod.GET)
    public String list(Model model, Pageable pageable) {        
        Page<Gastos> centroPage = entityService.findAll(pageable);
        PageWrapper<Gastos> page = new PageWrapper<Gastos>(centroPage, "/gastos");
        model.addAttribute("entities", page.getContent());
        model.addAttribute("page", page);
        model.addAttribute("entity", new Gastos());
        return "../gastos/index";
    }

    @RequestMapping("/gastos/refresh")
    public String refresh() {
        return "redirect:/gastos";
    }


    @RequestMapping("/gastos/create/{id}")
    public String create(@PathVariable Integer id, Model model) {
        model.addAttribute("entity", new Gastos());
        List<Plantaciones> list = plantacionesServices.getAll();
        model.addAttribute("plantaciones", list);
        return "../gastos/edit";
    }

    @RequestMapping("/gastos/edit/{id}")
    public String edit(@PathVariable Integer id, Model model) {
        model.addAttribute("entity", entityService.get(id));
        List<Plantaciones> list = plantacionesServices.getAll();
        model.addAttribute("plantaciones", list);
        return "../gastos/edit";
    }

    @RequestMapping(value = "gastos", method = RequestMethod.POST)
    public String save(Model model, @Validated Gastos entity) {
        String errores = "";
        if (entity.getFecha() == null) {
            errores += "Debe ingresar una fecha. ";
        }

        if (!errores.equals("")) {
            model.addAttribute("message", errores);
            model.addAttribute("entity", entity);
            List<Plantaciones> list = plantacionesServices.getAll();
            model.addAttribute("plantaciones", list);
            return "../gastos/edit";
        }

        entityService.save(entity);
        return "redirect:/gastos";
    }

    @RequestMapping("gastos/delete/{id}")
    public String delete(@PathVariable Integer id, Model model, Pageable pageable) {
        try {
            Gastos entity = entityService.get(id);
            entityService.delete(entity);
            return "redirect:/gastos";
        } catch (Exception e) {
            model.addAttribute("message", e.getMessage().toString());
            Page<Gastos> centroPage = entityService.findAll(pageable);
            PageWrapper<Gastos> page = new PageWrapper<Gastos>(centroPage, "/gastos");
            model.addAttribute("entities", page.getContent());
            model.addAttribute("page", page);
            model.addAttribute("entity", new Gastos());
            return "../gastos/index";
        }
    }   
    
}