package ar.com.practico6.dao;

import ar.com.practico6.entities.Usuarios;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IUsuariosDao extends JpaRepository<Usuarios, Integer> {
    @Query("select c from Usuarios c where c.usuario like ?1")
    List<Usuarios> findByDescrip(String name);

    @Query("select c from Usuarios c where c.usuario = ?1 and c.contrasenia = ?2")
    List<Usuarios> findUsuario(String usuario, String contrasenia, Pageable pagesize);

    Usuarios findOneByUsuario(String usuario);

    Page<Usuarios> findAll(Pageable pageable);
}
