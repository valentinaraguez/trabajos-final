package ar.com.practico6.controller;


import ar.com.practico6.entities.Especialidades;
import ar.com.practico6.entities.Profesionales;
import ar.com.practico6.entities.Tipodocs;
import ar.com.practico6.entities.Usuarios;
import ar.com.practico6.services.IEspecialidadesService;
import ar.com.practico6.services.IProfesionalesService;
import ar.com.practico6.services.ITipodocsService;
import ar.com.practico6.services.IUsuariosService;
import ar.com.practico6.utiles.PageWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@Controller
public class ProfesionalesController {

    @Autowired
    IProfesionalesService entityService;
    @Autowired
    ITipodocsService tipoService;
    @Autowired
    IEspecialidadesService espeService;
    @Autowired
    IUsuariosService usuarioService;
   
    @RequestMapping(value = "/profesionales", method = RequestMethod.GET)    
    public String list(Model model, Pageable pageable) {        
        Page<Profesionales> centroPage = entityService.findAll(pageable);
        PageWrapper<Profesionales> page = new PageWrapper<Profesionales>(centroPage, "/profesionales");
        model.addAttribute("entities", page.getContent());
        model.addAttribute("page", page);
        model.addAttribute("entity", new Profesionales());
        return "../profesionales/index";
    }

    @RequestMapping("/profesionales/refresh")
    public String refresh() {
        return "redirect:/profesionales";
    }

    @RequestMapping(value = "/profesionales/search", method = RequestMethod.POST)
    public String search(Model model, Profesionales entity) {
        if (entity.getNombre().equals("")) {
            return refresh();
        }
        model.addAttribute("entities", entityService.findByDescrip(entity.getNombre()));
        model.addAttribute("entity", new Profesionales());
        model.addAttribute("page", null); 
        return "../profesionales/index";
    }

    @RequestMapping("/profesionales/create/{id}")
    public String create(@PathVariable Integer id, Model model) {
        model.addAttribute("entity", new Profesionales());
        List<Tipodocs> list = tipoService.getAll();
        model.addAttribute("tipodocs", list);
        List<Especialidades> list2 = espeService.getAll();
        model.addAttribute("especialidades", list2);
        List<Usuarios> list3 = usuarioService.getAll();
        model.addAttribute("usuarios", list3);
        return "../profesionales/edit";
    }

    @RequestMapping("/profesionales/edit/{id}")
    public String edit(@PathVariable Integer id, Model model) {
        model.addAttribute("entity", entityService.get(id));
        List<Tipodocs> list = tipoService.getAll();
        model.addAttribute("tipodocs", list);
        List<Especialidades> list2 = espeService.getAll();
        model.addAttribute("especialidades", list2);
        List<Usuarios> list3 = usuarioService.getAll();
        model.addAttribute("usuarios", list3);
        return "../profesionales/edit";
    }

    @RequestMapping(value = "profesionales", method = RequestMethod.POST)
    public String save(Model model, @Validated Profesionales entity) {
        String errores = "";
        
        if (!errores.equals("")) {
            model.addAttribute("message", errores);
            model.addAttribute("entity", entity);
            List<Tipodocs> list = tipoService.getAll();
            model.addAttribute("tipodocs", list);
            List<Especialidades> list2 = espeService.getAll();
            model.addAttribute("especialidades", list2);
            List<Usuarios> list3 = usuarioService.getAll();
            model.addAttribute("usuarios", list3);
            return "../profesionales/edit";
        }

        entityService.save(entity);
        return "redirect:/profesionales";
    }

    @RequestMapping("profesionales/delete/{id}")
    public String delete(@PathVariable Integer id, Model model, Pageable pageable) {
        try {
            Profesionales entity = entityService.get(id);
            entityService.delete(entity);
            return "redirect:/profesionales";
        } catch (Exception e) {
            model.addAttribute("message", e.getMessage().toString());
            Page<Profesionales> centroPage = entityService.findAll(pageable);
            PageWrapper<Profesionales> page = new PageWrapper<Profesionales>(centroPage, "/profesionales");
            model.addAttribute("entities", page.getContent());
            model.addAttribute("page", page);
            model.addAttribute("entity", new Profesionales());
            return "../profesionales/index";
        }
    }   
    
}