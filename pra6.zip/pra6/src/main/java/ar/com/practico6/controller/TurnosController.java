package ar.com.practico6.controller;


import ar.com.practico6.entities.*;
import ar.com.practico6.services.*;
import ar.com.practico6.utiles.PageWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@Controller
public class TurnosController {

    @Autowired
    ITurnosService entityService;
    @Autowired
    IProfesionalesService profeService;
    @Autowired
    ITurnosGeneralesService turnoService;
    @Autowired
    IPacientesService pacienteService;
    @Autowired
    IObrasSocialesService obraService;
   
   
    @RequestMapping(value = "/turnos", method = RequestMethod.GET)    
    public String list(Model model, Pageable pageable) {        
        Page<Turnos> centroPage = entityService.findAll(pageable);
        PageWrapper<Turnos> page = new PageWrapper<Turnos>(centroPage, "/turnos");
        model.addAttribute("entities", page.getContent());
        model.addAttribute("page", page);
        model.addAttribute("entity", new Turnos());
        return "../turnos/index";
    }

    @RequestMapping("/turnos/refresh")
    public String refresh() {
        return "redirect:/turnos";
    }

    @RequestMapping(value = "/turnos/search", method = RequestMethod.POST)
    public String search(Model model, Turnos entity) {
        return refresh();
    }

    @RequestMapping("/turnos/create/{id}")
    public String create(@PathVariable String id, Model model) {
        model.addAttribute("entity", new Turnos());
        List<Profesionales> list = profeService.getAll();
        model.addAttribute("profesionales", list);
        List<TurnosGenerales> list2 = turnoService.getAll();
        model.addAttribute("turnosgenerales", list2);
        List<Pacientes> list3 = pacienteService.getAll();
        model.addAttribute("pacientes", list3);
        List<ObrasSociales> list4 = obraService.getAll();
        model.addAttribute("obrassociales", list4);
        return "../turnos/edit";
    }

    @RequestMapping("/turnos/edit/{id}")
    public String edit(@PathVariable String id, Model model) {
        model.addAttribute("entity", entityService.get(id));
        List<Profesionales> list = profeService.getAll();
        model.addAttribute("profesionales", list);
        List<TurnosGenerales> list2 = turnoService.getAll();
        model.addAttribute("turnosgenerales", list2);
        List<Pacientes> list3 = pacienteService.getAll();
        model.addAttribute("pacientes", list3);
        List<ObrasSociales> list4 = obraService.getAll();
        model.addAttribute("obrassociales", list4);
        return "../turnos/edit";
    }

    @RequestMapping(value = "turnos", method = RequestMethod.POST)
    public String save(Model model, @Validated Turnos entity) {
        String errores = "";
        
        if (!errores.equals("")) {
            model.addAttribute("message", errores);
            model.addAttribute("entity", entity);
            List<Profesionales> list = profeService.getAll();
            model.addAttribute("profesionales", list);
            List<TurnosGenerales> list2 = turnoService.getAll();
            model.addAttribute("turnosgenerales", list2);
            List<Pacientes> list3 = pacienteService.getAll();
            model.addAttribute("pacientes", list3);
            List<ObrasSociales> list4 = obraService.getAll();
            model.addAttribute("obrassociales", list4);
            return "../turnos/edit";
        }

        entityService.save(entity);
        return "redirect:/turnos";
    }

    @RequestMapping("turnos/delete/{id}")
    public String delete(@PathVariable String id, Model model, Pageable pageable) {
        try {
            Turnos entity = entityService.get(id);
            entityService.delete(entity);
            return "redirect:/turnos";
        } catch (Exception e) {
            model.addAttribute("message", e.getMessage().toString());
            Page<Turnos> centroPage = entityService.findAll(pageable);
            PageWrapper<Turnos> page = new PageWrapper<Turnos>(centroPage, "/turnos");
            model.addAttribute("entities", page.getContent());
            model.addAttribute("page", page);
            model.addAttribute("entity", new Turnos());
            return "../turnos/index";
        }
    }   
    
}