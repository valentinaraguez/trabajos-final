package ar.com.practico6.dao;

import ar.com.practico6.entities.Tipodocs;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ITipodocsDao extends JpaRepository<Tipodocs, Integer> {
    @Query("select c from Tipodocs c where c.descrip like ?1")
    public List<Tipodocs> findByDescrip(String name);
    
    Page<Tipodocs> findAll(Pageable pageable);
}
