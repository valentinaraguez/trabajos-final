package ar.com.practico6.services;

import ar.com.practico6.entities.TurnosProfesionales;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ITurnosProfesionalesService {
    List<TurnosProfesionales> getAll();
    TurnosProfesionales get(String id);
    void save(TurnosProfesionales entity);
    String delete(TurnosProfesionales entity);
    Page<TurnosProfesionales> findAll(Pageable pageable);

}
