package ar.com.practico6.servicesimp;

import ar.com.practico6.dao.IObrasSocialesDao;
import ar.com.practico6.entities.ObrasSociales;
import ar.com.practico6.services.IObrasSocialesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ObrasSocialesService implements IObrasSocialesService {

    @Autowired
    private IObrasSocialesDao entityDao;

    public List<ObrasSociales> getAll() {
        return entityDao.findAll(Sort.by(Sort.Direction.ASC, "nombre"));
    }

    public Page<ObrasSociales> findAll(Pageable pageable) {
        return entityDao.findAll(PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by(Sort.Direction.ASC, "nombre")));
    }

    public List<ObrasSociales> findByDescrip(String descrip) {
        return entityDao.findByDescrip("%" + descrip + "%");
    }

    public ObrasSociales get(String id) {
        return entityDao.findById(id).orElse(null);
    }

    @Transactional
    public void save(ObrasSociales entity) {
        entityDao.save(entity);
    }

    @Transactional
    public String delete(ObrasSociales entity) {
        try {
            entityDao.delete(entity);
            return null;
        } catch (Exception e) {
            return e.getMessage().toString();
        }
    }
}
