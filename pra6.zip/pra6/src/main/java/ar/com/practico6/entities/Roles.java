package ar.com.practico6.entities;

import jakarta.persistence.*;

import java.io.Serializable;

@Entity
@Table(name = "roles")
public class Roles implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String descrip;
    private int nivelacceso;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDescrip() {
        return descrip;
    }

    public void setDescrip(String descrip) {
        this.descrip = descrip;
    }

    public int getNivelacceso() {
        return nivelacceso;
    }

    public void setNivelacceso(int nivelacceso) {
        this.nivelacceso = nivelacceso;
    }

    public long getSerialVersionUID() {
        return serialVersionUID;
    }
}
