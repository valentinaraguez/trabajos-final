package ar.com.practico6.dao;

import ar.com.practico6.entities.TurnosProfesionales;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ITurnosProfesionalesDao extends JpaRepository<TurnosProfesionales, String> {

    Page<TurnosProfesionales> findAll(Pageable pageable);
}
