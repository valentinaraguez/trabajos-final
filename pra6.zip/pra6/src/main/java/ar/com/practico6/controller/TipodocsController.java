package ar.com.practico6.controller;

import ar.com.practico6.entities.Tipodocs;
import ar.com.practico6.services.ITipodocsService;
import ar.com.practico6.utiles.PageWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class TipodocsController {

    @Autowired
    ITipodocsService entityService;

    @RequestMapping(value = "/tipodocs", method = RequestMethod.GET)
    public String list(Model model, Pageable pageable) {        
        Page<Tipodocs> centroPage = entityService.findAll(pageable);
        PageWrapper<Tipodocs> page = new PageWrapper<Tipodocs>(centroPage, "/tipodocs");
        model.addAttribute("entities", page.getContent());
        model.addAttribute("page", page);
        model.addAttribute("entity", new Tipodocs());
        return "../tipodocs/index";
    }

    @RequestMapping("tipodocs/refresh")
    public String refresh() {
        return "redirect:/tipodocs";
    }

    @RequestMapping(value = "tipodocs/search", method = RequestMethod.POST)
    public String search(Model model, Tipodocs entity) {
        if (entity.getDescrip().equals("")) {
            return refresh();
        }
        model.addAttribute("entities", entityService.findByDescrip(entity.getDescrip()));
        model.addAttribute("entity", new Tipodocs());
        model.addAttribute("page", null);
        return "../tipodocs/index";
    }

    @RequestMapping("tipodocs/create/{id}")
    public String create(@PathVariable Integer id, Model model) {
        model.addAttribute("entity", new Tipodocs());
        return "../tipodocs/edit";
    }

    @RequestMapping("tipodocs/edit/{id}")
    public String edit(@PathVariable Integer id, Model model) {
        model.addAttribute("entity", entityService.get(id));
        return "../tipodocs/edit";
    }

    @RequestMapping(value = "tipodocs", method = RequestMethod.POST)
    public String save(Model model, @Validated Tipodocs entity) {
        if (entity.getDescrip().equals("")) {
            model.addAttribute("message", "Descripción Incorrecta");
            model.addAttribute("entity", entity);
            return "../tipodocs/edit";
        }

        entityService.save(entity);
        return "redirect:/tipodocs";
    }

    @RequestMapping("tipodocs/delete/{id}")
    public String delete(@PathVariable Integer id, Model model, Pageable pageable) {
        try {
            Tipodocs entity = entityService.get(id);
            entityService.delete(entity);
            return "redirect:/tipodocs";
        } catch (Exception e) {
            model.addAttribute("message", e.getMessage().toString());
            Page<Tipodocs> centroPage = entityService.findAll(pageable);
            PageWrapper<Tipodocs> page = new PageWrapper<Tipodocs>(centroPage, "/tipodocs");
            model.addAttribute("entities", page.getContent());
            model.addAttribute("page", page);
            model.addAttribute("entity", new Tipodocs());
            return "../tipodocs/index";
        }
    }
    
}