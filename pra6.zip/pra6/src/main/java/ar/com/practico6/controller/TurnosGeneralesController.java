package ar.com.practico6.controller;


import ar.com.practico6.entities.*;
import ar.com.practico6.services.*;
import ar.com.practico6.utiles.PageWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@Controller
public class TurnosGeneralesController {

    @Autowired
    ITurnosGeneralesService entityService;
    @Autowired
    IDiasService diaService;
    @Autowired
    IHorariosService horaService;
   
   
    @RequestMapping(value = "/turnosgenerales", method = RequestMethod.GET)    
    public String list(Model model, Pageable pageable) {        
        Page<TurnosGenerales> centroPage = entityService.findAll(pageable);
        PageWrapper<TurnosGenerales> page = new PageWrapper<TurnosGenerales>(centroPage, "/turnosgenerales");
        model.addAttribute("entities", page.getContent());
        model.addAttribute("page", page);
        model.addAttribute("entity", new TurnosGenerales());
        return "../turnosgenerales/index";
    }

    @RequestMapping("/turnosgenerales/refresh")
    public String refresh() {
        return "redirect:/turnosgenerales";
    }

    @RequestMapping(value = "/turnosgenerales/search", method = RequestMethod.POST)
    public String search(Model model, TurnosGenerales entity) {
        return refresh();
    }

    @RequestMapping("/turnosgenerales/create/{id}")
    public String create(@PathVariable String id, Model model) {
        model.addAttribute("entity", new TurnosGenerales());
        List<Dias> list = diaService.getAll();
        model.addAttribute("dias", list);
        List<Horarios> list2 = horaService.getAll();
        model.addAttribute("horarios", list2);
        return "../turnosgenerales/edit";
    }

    @RequestMapping("/turnosgenerales/edit/{id}")
    public String edit(@PathVariable String id, Model model) {
        model.addAttribute("entity", entityService.get(id));
        List<Dias> list = diaService.getAll();
        model.addAttribute("dias", list);
        List<Horarios> list2 = horaService.getAll();
        model.addAttribute("horarios", list2);
        return "../turnosgenerales/edit";
    }

    @RequestMapping(value = "turnosgenerales", method = RequestMethod.POST)
    public String save(Model model, @Validated TurnosGenerales entity) {
        String errores = "";
        
        if (!errores.equals("")) {
            model.addAttribute("message", errores);
            model.addAttribute("entity", entity);
            List<Dias> list = diaService.getAll();
            model.addAttribute("dias", list);
            List<Horarios> list2 = horaService.getAll();
            model.addAttribute("horarios", list2);
            return "../turnosgenerales/edit";
        }

        entityService.save(entity);
        return "redirect:/turnosgenerales";
    }

    @RequestMapping("turnosgenerales/delete/{id}")
    public String delete(@PathVariable String id, Model model, Pageable pageable) {
        try {
            TurnosGenerales entity = entityService.get(id);
            entityService.delete(entity);
            return "redirect:/turnosgenerales";
        } catch (Exception e) {
            model.addAttribute("message", e.getMessage().toString());
            Page<TurnosGenerales> centroPage = entityService.findAll(pageable);
            PageWrapper<TurnosGenerales> page = new PageWrapper<TurnosGenerales>(centroPage, "/turnosgenerales");
            model.addAttribute("entities", page.getContent());
            model.addAttribute("page", page);
            model.addAttribute("entity", new TurnosGenerales());
            return "../turnosgenerales/index";
        }
    }   
    
}